package com.example.proyectosaurus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class QuizActivity : AppCompatActivity() {
    private lateinit var questionTextView: TextView
    private lateinit var answersRadioGroup: RadioGroup
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_quiz)

        // Setting up window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        questionTextView = findViewById(R.id.question_text_view)
        answersRadioGroup = findViewById(R.id.answers_radio_group)
        submitButton = findViewById(R.id.submit_button)
        val btnVolver = findViewById<Button>(R.id.btnVolver)

        btnVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        // Set up the submit button click listener
        submitButton.setOnClickListener {
            val selectedOptionId = answersRadioGroup.checkedRadioButtonId
            if (selectedOptionId != -1) {
                val selectedRadioButton = findViewById<RadioButton>(selectedOptionId)
                val answer = selectedRadioButton.text.toString()
                checkAnswer(answer)
            } else {
                Toast.makeText(this, "Por favor, selecciona una respuesta", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkAnswer(answer: String) {
        val correctAnswer = "B) Brachiosaurus"  // Example correct answer
        if (answer == correctAnswer) {
            Toast.makeText(this, "¡Correcto!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Incorrecto. La respuesta correcta es: $correctAnswer", Toast.LENGTH_SHORT).show()
        }
    }
}