package com.example.proyectosaurus

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_TABLE_DINOSAURIOS)
        db.execSQL(CREATE_TABLE_USUARIOS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_DINOSAURIOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USUARIOS")
        onCreate(db)
    }

    fun registrarUsuario(nombre: String, email: String, contraseña: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombre", nombre)
            put("email", email)
            put("contraseña", contraseña)
            put("preferencias", "General") // Valor por defecto para preferencias
        }
        val result = db.insert(TABLE_USUARIOS, null, values)
        return result != -1L
    }

    fun buscarUsuario(email: String, contraseña: String): Usuario? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_USUARIOS, null, "email = ? AND contraseña = ?", arrayOf(email, contraseña),
            null, null, null
        )
        return if (cursor != null && cursor.moveToFirst()) {
            val usuario = Usuario(
                cursor.getString(cursor.getColumnIndexOrThrow("nombre")) ?: "Sin Nombre",
                cursor.getString(cursor.getColumnIndexOrThrow("email")) ?: "",
                cursor.getString(cursor.getColumnIndexOrThrow("contraseña")) ?: "",
                cursor.getString(cursor.getColumnIndexOrThrow("preferencias")) ?: "General"
            )
            cursor.close()
            usuario
        } else {
            cursor?.close()
            null
        }
    }

    fun registrarDinosaurio(nombre: String, caracteristicas: String, habitat: String, epoca: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombre", nombre)
            put("caracteristicas", caracteristicas)
            put("habitat", habitat)
            put("epoca", epoca)
        }
        val result = db.insert(TABLE_DINOSAURIOS, null, values)
        return result != -1L
    }

    fun buscarDinosaurio(nombre: String): Dinosaurio? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_DINOSAURIOS, null, "nombre = ?", arrayOf(nombre),
            null, null, null
        )
        return if (cursor != null && cursor.moveToFirst()) {
            val dinosaurio = Dinosaurio(
                cursor.getString(cursor.getColumnIndexOrThrow("nombre")) ?: "Desconocido",
                cursor.getString(cursor.getColumnIndexOrThrow("caracteristicas")) ?: "",
                cursor.getString(cursor.getColumnIndexOrThrow("habitat")) ?: "",
                cursor.getString(cursor.getColumnIndexOrThrow("epoca")) ?: ""
            )
            cursor.close()
            dinosaurio
        } else {
            cursor?.close()
            null
        }
    }

    fun obtenerDinosaurios(): List<Dinosaurio> {
        val dinosaurios = mutableListOf<Dinosaurio>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_DINOSAURIOS", null)
        if (cursor != null && cursor.moveToFirst()) {
            do {
                val dinosaurio = Dinosaurio(
                    cursor.getString(cursor.getColumnIndexOrThrow("nombre")) ?: "Desconocido",
                    cursor.getString(cursor.getColumnIndexOrThrow("caracteristicas")) ?: "",
                    cursor.getString(cursor.getColumnIndexOrThrow("habitat")) ?: "",
                    cursor.getString(cursor.getColumnIndexOrThrow("epoca")) ?: ""
                )
                dinosaurios.add(dinosaurio)
            } while (cursor.moveToNext())
        }
        cursor?.close()
        return dinosaurios
    }

    companion object {
        private const val DATABASE_NAME = "paleontologia.db"
        private const val DATABASE_VERSION = 2 // Aumenta la versión para aplicar cambios en la base de datos

        private const val TABLE_DINOSAURIOS = "Dinosaurios"
        private const val TABLE_USUARIOS = "Usuarios"

        private const val CREATE_TABLE_DINOSAURIOS =
            "CREATE TABLE $TABLE_DINOSAURIOS (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, caracteristicas TEXT, habitat TEXT, epoca TEXT, imagen BLOB)"
        private const val CREATE_TABLE_USUARIOS =
            "CREATE TABLE $TABLE_USUARIOS (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, email TEXT UNIQUE, contraseña TEXT, preferencias TEXT)"
    }

    data class Dinosaurio(
        val nombre: String,
        val caracteristicas: String,
        val habitat: String,
        val epoca: String
    )

    data class Usuario(
        val nombre: String,
        val email: String,
        val contraseña: String,
        val preferencias: String
    )
}
