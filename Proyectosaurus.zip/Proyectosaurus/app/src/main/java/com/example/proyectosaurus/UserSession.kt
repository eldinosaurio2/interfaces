package com.example.proyectosaurus

object UserSession {
    var isLoggedIn: Boolean = false
        private set

    var nombre: String? = null
    var email: String? = null
    var preferencias: String? = null

    fun logIn(name: String, email: String, preferencias: String?) {
        this.isLoggedIn = true
        this.nombre = name
        this.email = email
        this.preferencias = preferencias
    }

    fun logOut() {
        clear()
        isLoggedIn = false
    }

    private fun clear() {
        nombre = null
        email = null
        preferencias = null
    }
}