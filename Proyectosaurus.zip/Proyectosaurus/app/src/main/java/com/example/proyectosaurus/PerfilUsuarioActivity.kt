package com.example.proyectosaurus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PerfilUsuarioActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_usuario)

        val tvNombre = findViewById<TextView>(R.id.tvNombre)
        val tvEmail = findViewById<TextView>(R.id.tvEmail)
        val tvPreferencias = findViewById<TextView>(R.id.tvPreferencias)

        val btnVolver = findViewById<Button>(R.id.btnVolver)
        btnVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }


        // Acceder a los datos desde UserSession
        tvNombre.text = "Nombre: ${UserSession.nombre ?: "No disponible"}"
        tvEmail.text = "Email: ${UserSession.email ?: "No disponible"}"
        tvPreferencias.text = "Preferencias: ${UserSession.preferencias ?: "No especificadas"}"
    }
}


