package com.example.proyectosaurus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GuiaPaleontologicaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guia_paleontologica)

        val etBuscarDinosaurio = findViewById<EditText>(R.id.etBuscarDinosaurio)
        val btnBuscar = findViewById<Button>(R.id.btnBuscar)
        val btnVolver = findViewById<Button>(R.id.btnVolver)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        val db = DatabaseHelper(this)

        btnVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        btnBuscar.setOnClickListener {
            val nombre = etBuscarDinosaurio.text.toString()
            val dinosaurio = db.buscarDinosaurio(nombre)
            tvResultado.text = dinosaurio?.caracteristicas ?: "Dinosaurio no encontrado"
        }
    }
}
