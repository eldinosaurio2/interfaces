package com.example.proyectosaurus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener {
    private lateinit var gestureDetector: GestureDetector
    private val REQUEST_CODE_SPEECH_INPUT = 100
    private val REQUEST_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Chequeo para redirigir al LoginActivity si no está logueado
        if (!UserSession.isLoggedIn) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        gestureDetector = GestureDetector(this, this)

        // Declarar los valores de los botones
        val btnDinosaurios = findViewById<Button>(R.id.btnDinosaurios)
        val btnPerfil = findViewById<Button>(R.id.btnPerfil)
        val btnExploracion = findViewById<Button>(R.id.btnExploracion)
        val btnGuia = findViewById<Button>(R.id.btnGuia)
        val btnQuiz = findViewById<Button>(R.id.btnQuiz)
        val btnVoiceCommand = findViewById<Button>(R.id.btnVoiceCommand)

        // Configurar listeners para los botones
        btnDinosaurios.setOnClickListener {
            startActivity(Intent(this, DinosauriosActivity::class.java))
        }

        btnPerfil.setOnClickListener {
            startActivity(Intent(this, PerfilUsuarioActivity::class.java))
        }

        btnExploracion.setOnClickListener {
            startActivity(Intent(this, ExploracionEpocasActivity::class.java))
        }

        btnGuia.setOnClickListener {
            startActivity(Intent(this, GuiaPaleontologicaActivity::class.java))
        }

        btnQuiz.setOnClickListener {
            startActivity(Intent(this, QuizActivity::class.java))
        }

        btnVoiceCommand.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_PERMISSION_CODE)
            } else {
                startVoiceInput()
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    override fun onDown(e: MotionEvent): Boolean {
        return true
    }

    override fun onShowPress(e: MotionEvent) {
    }

    override fun onSingleTapUp(e: MotionEvent): Boolean {
        Toast.makeText(this, "Tap detectado", Toast.LENGTH_SHORT).show()
        return true
    }

    override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
        return true
    }

    override fun onLongPress(e: MotionEvent) {
    }

    override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
        return true
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hola, di algo!")
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: Exception) {
            Toast.makeText(this, "Error: " + e.message, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val recognizedText = result?.get(0)
                handleVoiceCommand(recognizedText)
            }
        }
    }

    private fun handleVoiceCommand(command: String?) {
        when (command?.toLowerCase(Locale.ROOT)) {
            "abrir guía" -> startActivity(Intent(this, GuiaPaleontologicaActivity::class.java))
            "iniciar quiz" -> startActivity(Intent(this, QuizActivity::class.java))
            "mostrar perfil" -> startActivity(Intent(this, PerfilUsuarioActivity::class.java))
            "buscar dinosaurio" -> startActivity(Intent(this, GuiaPaleontologicaActivity::class.java))
            "mostrar exploraciones" -> startActivity(Intent(this, ExploracionEpocasActivity::class.java))
            "mostrar dinosaurios" -> startActivity(Intent(this, DinosauriosActivity::class.java))
            else -> Toast.makeText(this, "Comando no reconocido", Toast.LENGTH_SHORT).show()
        }
    }

    // Manejar la respuesta de la solicitud de permisos
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                // Permiso concedido, iniciar reconocimiento de voz
                startVoiceInput()
            } else {
                // Permiso denegado, mostrar mensaje al usuario
                Toast.makeText(this, "Permiso de grabación denegado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
