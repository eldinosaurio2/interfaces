package com.example.proyectosaurus

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ExploracionEpocasActivity : AppCompatActivity() {

    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exploracion_epocas)

        val btnJurassico = findViewById<Button>(R.id.btnJurassico)
        val btnTriassico = findViewById<Button>(R.id.btnTriassico)
        val btnCretacico = findViewById<Button>(R.id.btnCretacico)
        val ivEpoca = findViewById<ImageView>(R.id.ivEpoca)
        val tvEpoca = findViewById<TextView>(R.id.tvEpoca)
        val btnVolver = findViewById<Button>(R.id.btnVolver)
        btnVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        btnJurassico.setOnClickListener {
            ivEpoca.setImageResource(R.drawable.jurasico)
            tvEpoca.text = "El periodo Jurásico se extiende desde aproximadamente 201 a 145 millones de años atrás. Es famoso por la diversificación de los dinosaurios y la aparición de los primeros pájaros."
            playAudio(R.raw.jurasico)
        }

        btnTriassico.setOnClickListener {
            ivEpoca.setImageResource(R.drawable.triasico)
            tvEpoca.text = "El periodo Triásico se extiende desde aproximadamente 252 a 201 millones de años atrás. Es conocido por la aparición de los primeros dinosaurios y mamíferos."
            playAudio(R.raw.triasico)
        }

        btnCretacico.setOnClickListener {
            ivEpoca.setImageResource(R.drawable.cretacico)
            tvEpoca.text = "El periodo Cretácico se extiende desde aproximadamente 145 a 66 millones de años atrás. Es conocido por la aparición de las primeras plantas con flores y la extinción masiva que acabó con los dinosaurios."
            playAudio(R.raw.cretacico)
        }
    }

    private fun playAudio(audioResId: Int) {
        // Detiene cualquier reproducción actual y libera el recurso
        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }

        // Inicializa el MediaPlayer con el nuevo archivo de audio
        mediaPlayer = MediaPlayer.create(this, audioResId)
        mediaPlayer.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Libera el MediaPlayer cuando la actividad es destruida
        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }
    }
}
