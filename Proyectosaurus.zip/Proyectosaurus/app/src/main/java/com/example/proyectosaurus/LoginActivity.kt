package com.example.proyectosaurus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Referencias a los componentes de la UI
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etContraseña = findViewById<EditText>(R.id.etContraseña)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        // Inicializamos la base de datos
        val dbHelper = DatabaseHelper(this)

        // Acción al presionar el botón de login
        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val contraseña = etContraseña.text.toString()

            // Validamos que los campos no estén vacíos
            if (email.isNotEmpty() && contraseña.isNotEmpty()) {
                // Buscamos el usuario en la base de datos
                val usuario = dbHelper.buscarUsuario(email, contraseña)

                if (usuario != null) {
                    // Si el usuario existe, mostramos un mensaje y redirigimos a MainActivity
                    Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this, MainActivity::class.java).apply {
                        putExtra("nombre", usuario.nombre)
                        putExtra("email", usuario.email)
                        putExtra("preferencias", usuario.preferencias)
                    }
                    UserSession.logIn(usuario.nombre, usuario.email, usuario.preferencias)
                    startActivity(intent)

                    // Cerramos la LoginActivity para que el usuario no regrese al presionar 'atrás'
                    finish()
                } else {
                    // Usuario no encontrado o credenciales incorrectas
                    Toast.makeText(this, "Email o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Si los campos están vacíos, mostramos un mensaje de advertencia
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
